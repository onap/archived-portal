 
  var GaugeWidget = (function(window, undefined) {

	var GaugeWidget = GaugeWidget || {};

	function extractHostPortApp(src) {
		
		GaugeWidget.pathArray = src.split( '/' );
		
		//widgetname would be the second last element in the split array 	
		GaugeWidget.widgetName = GaugeWidget.pathArray[GaugeWidget.pathArray.length - 2];
		GaugeWidget.serviceSeperator = GaugeWidget.pathArray[GaugeWidget.pathArray.length - 4];
		
		//Everything before the widget name will be the common part of the url that controller, markup and css can use
		GaugeWidget.commonUrl = src.substring(0, src.lastIndexOf("/" + GaugeWidget.widgetName));
		GaugeWidget.recipientDivDataAttrib = 'data-' + GaugeWidget.widgetName;
		GaugeWidget.controllerName = 'GaugeCtrl'
		GaugeWidget.readyCssFlag = 'gauge-css-ready';
		GaugeWidget.readyCssFlagExpectedValue = '#bada55';
		GaugeWidget.serviceURL = src.substring(0, src.lastIndexOf("/" + GaugeWidget.serviceSeperator)) + '/raptor.htm?action=report.run.container&c_master=15&refresh=Y';
		//'https://webtest.csp.att.com/ecompportal/ecompportal/raptor.htm?action=report.run.container&c_master=15&refresh=Y'	
	}
	
	extractHostPortApp(document.currentScript.src);
	
	//Stylesheet related
	function loadStylesheet(url) {
		var link = document.createElement('link');
		link.rel = 'stylesheet';
		link.type = 'text/css';
		link.href = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(link, entry);
	}

	function isCssReady(callback) {
		
		var testElem = document.createElement('span');
		testElem.id = GaugeWidget.readyCssFlag;	
		
		//Reason for giving this in-line color to the test element is to eliminate the rare chance
		//of another script assigning our magic color (#bada55) to the test element - (and has loaded before our script has)

		testElem.style = 'color: #fff';
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(testElem, entry);
	
		(function poll() {
			var node = document.getElementById('css-ready');
			var value;
			
			//W3C Standard way of accessing style - converts hex value to the RGB expression.
			if (window.getComputedStyle) {
				value = document.defaultView.getComputedStyle(testElem, null)
						.getPropertyValue('color');
			} 
			//For IE8 and below, use this - They are still using obsolete currentStype value
			//preserving the original hex value.
			else if (node.currentStyle) {
				value = node.currentStyle.color;
			}
			
			//Check for both hex value and RGB expression to address IE8 and below and other browsers.
			if (value && value === 'rgb(186, 218, 85)' || value.toLowerCase() === GaugeWidget.readyCssFlagExpectedValue) {
				callback();
			} else {
				setTimeout(poll, 500);
			}

		})();
	}
	
	function injectCss(css) {
		var style = document.createElement('style');
		style.type = 'text/css';
		css = css.replace(/\}/g, "}\n");
	
		if (style.styleSheet) {
			//IE uses cssText property
			style.styleSheet.cssText = css;
		} else {
			//Other browsers can append new DOM text node
			style.appendChild(document.createTextNode(css));
		}
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(style, entry);
	}
	
	function loadScript(url, callback) {
		var script = document.createElement('script');
		// script.async = true;
		script.src = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(script, entry);
		script.onload = script.onreadystatechange = function() {
			var rdyState = script.readyState;
			if (!rdyState || /complete|loaded/.test(script.readyState)) {
				callback();
				script.onload = null;
				script.onreadystatechange = null;
			}
		};
	}

	function loadSupportingFiles(callback) {
		callback();
	}
	
	function getWidgetParams() {
	}
	
	function getCookies(){
	  var pairs = document.cookie.split(";");
	  var cookies = {};
	  for (var i=0; i<pairs.length; i++){
		var pair = pairs[i].split("=");
		cookies[pair[0]] = unescape(pair[1]);
	  }
	  return cookies;
	}

	function getWidgetData(widgetUrl, callback) {
		
		var responseData;
		
		try{
			jQuery.ajax({
				url: widgetUrl,
				success: function (result) {
					if (result.isOk == false){
					
					}
					else{
						
						var reportData = result.reportDataRows;
						reportData = tranpose(reportData);
						responseData = JSONToCSVConvertor(reportData);
					}
				},
				//not recommended to use synchronous - ikram will change
				async: false
			});
		}		
		catch(e){
		}
		callback(responseData);
	}
	
		function tranpose(JSONData){
			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
		
			var map = new Map();
			for (var i = 0; i < arrData.length; i++) {
				var record = {};
				var day;
				for (var index in arrData[i]) {
					
					if(index === 'app_name'){
						record['name'] = arrData[i][index].displayValue;
					}
					
					else if(index === 'ct'){
						record['ct'] = arrData[i][index].displayValue;
					}
					
					else if(index === 'audit_date'){
						day = arrData[i][index].displayValue;
					}
					
					else if(index === 'app_id'){
						record['id']  = arrData[i][index].displayValue;
					}
				}
				
				map[day] = map[day] || [];
				map[day].push(record);	
			}
			return map;
		}
		
		function JSONToCSVConvertor(JSONData) {

			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
			var keys = Object.keys(arrData);
			var CSV = '';
			var firstIndex = true;
			var appIds = [];
			var appNames = [];
			
			for(var i = keys.length-1; i >= 0; i--){
				var row = '"' + keys[i] + '"' + ',';
				var firstRow = '"YEARMONTH",';
				for(var n = 0; n < arrData[keys[i]].length; n++){
					var comma = n === arrData[keys[i]].length-1 ? '' : ',';
					if(firstIndex){
						firstRow += '"widget_' + arrData[keys[i]][n].id + '"' + comma;
						appIds.push('widget_' + arrData[keys[i]][n].id);
						appNames.push(arrData[keys[i]][n].name);
					}
					row += '"' + arrData[keys[i]][n].ct + '"'  + comma;
				}
				if(firstIndex){
					CSV += firstRow + '\n';
					GaugeWidget.headerIds = appIds;
					GaugeWidget.headerNames = appNames;
					firstIndex = false;
				}
				CSV += row + '\n';
			}
			return CSV;
		}

	
	function getMarkupContent(markupLocation, target){
		
		jQuery.ajax({
	        url: markupLocation,
		    success: function (result) {
	            if (result.isOk == false){
					
				}
	            else{
	            	target.innerHTML = result;
				}
	        },
	        //not recommended to use synchronous - ikram will change
	        async: false
	    });
	}
	
	function renderWidget(widgetData, location) {
		var div = document.createElement('div');
		getMarkupContent(GaugeWidget.commonUrl + "/markup/" + GaugeWidget.widgetName, div);
		location.append(div);
		
		GaugeWidget.widgetData = widgetData;
		
		app.controllerProvider.register(GaugeWidget.controllerName, GaugeWidget.controller);
	
		//printAllArtifacts('ecompApp');
		var mController = angular.element(document.getElementById("widgets"));
		mController.scope().activateThis(location, widgetData);
		
	}
	
	function printAllArtifacts(moduleName, controllerName) {
	    var queue = angular.module(moduleName)._invokeQueue;
	    for(var i=0;i<queue.length;i++) {
	        var call = queue[i];
	    }
	}
	
	function get(name){
	   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
	      return decodeURIComponent(name[1]);
	}

	loadSupportingFiles(function() {
		
		GaugeWidget.noData = false;
		loadStylesheet(GaugeWidget.commonUrl + '/' + GaugeWidget.widgetName + '/style.css');		
		loadScript(GaugeWidget.commonUrl + '/' + GaugeWidget.widgetName + '/controller.js',
			function() {
				$('['+ GaugeWidget.recipientDivDataAttrib + ']').each(function() {
					var location = jQuery(this);
					location.removeAttr(GaugeWidget.recipientDivDataAttrib);
					var id = location.attr(GaugeWidget.recipientDivDataAttrib);
					getWidgetData(GaugeWidget.serviceURL, function(widgetData) {
						if(widgetData == ''){
							GaugeWidget.noData = true;
						}
						isCssReady(function(){
							renderWidget(widgetData, location);
						});								
					});
				});
			}
		);
	});	
	return GaugeWidget;	
})(window);
