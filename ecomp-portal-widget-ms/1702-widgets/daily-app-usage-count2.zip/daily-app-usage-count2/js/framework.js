 
  var AreaWidget = (function(window, undefined) {

	var AreaWidget = AreaWidget || {};

	function extractHostPortApp(src) {
		
		AreaWidget.pathArray = src.split( '/' );
		
		//widgetname would be the second last element in the split array 	
		AreaWidget.widgetName = AreaWidget.pathArray[AreaWidget.pathArray.length - 2];
		AreaWidget.serviceSeperator = AreaWidget.pathArray[AreaWidget.pathArray.length - 4];
		
		//Everything before the widget name will be the common part of the url that controller, markup and css can use
		AreaWidget.commonUrl = src.substring(0, src.lastIndexOf("/" + AreaWidget.widgetName));
		AreaWidget.recipientDivDataAttrib = 'data-' + AreaWidget.widgetName;
		AreaWidget.controllerName = 'AreaCtrl'
		AreaWidget.readyCssFlag = 'area-css-ready';
		AreaWidget.readyCssFlagExpectedValue = '#bada55';
		AreaWidget.serviceURL = src.substring(0, src.lastIndexOf("/" + AreaWidget.serviceSeperator)) + '/raptor.htm?action=report.run.container&c_master=18&refresh=Y';
		//'https://webtest.csp.att.com/ecompportal/ecompportal/raptor.htm?action=report.run.container&c_master=17&refresh=Y'
	}
	
	extractHostPortApp(document.currentScript.src);
	
	//Stylesheet related
	function loadStylesheet(url) {
		var link = document.createElement('link');
		link.rel = 'stylesheet';
		link.type = 'text/css';
		link.href = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(link, entry);
	}

	function isCssReady(callback) {
		
		var testElem = document.createElement('span');
		testElem.id = AreaWidget.readyCssFlag;	
		
		//Reason for giving this in-line color to the test element is to eliminate the rare chance
		//of another script assigning our magic color (#bada55) to the test element - (and has loaded before our script has)

		testElem.style = 'color: #fff';
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(testElem, entry);
	
		(function poll() {
			var node = document.getElementById('css-ready');
			var value;
			
			//W3C Standard way of accessing style - converts hex value to the RGB expression.
			if (window.getComputedStyle) {
				value = document.defaultView.getComputedStyle(testElem, null)
						.getPropertyValue('color');
			} 
			//For IE8 and below, use this - They are still using obsolete currentStype value
			//preserving the original hex value.
			else if (node.currentStyle) {
				value = node.currentStyle.color;
			}
			
			//Check for both hex value and RGB expression to address IE8 and below and other browsers.
			if (value && value === 'rgb(186, 218, 85)' || value.toLowerCase() === AreaWidget.readyCssFlagExpectedValue) {
				callback();
			} else {
				setTimeout(poll, 500);
			}

		})();
	}
	
	function injectCss(css) {
		var style = document.createElement('style');
		style.type = 'text/css';
		css = css.replace(/\}/g, "}\n");
	
		if (style.styleSheet) {
			//IE uses cssText property
			style.styleSheet.cssText = css;
		} else {
			//Other browsers can append new DOM text node
			style.appendChild(document.createTextNode(css));
		}
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(style, entry);
	}
	
	function loadScript(url, callback) {
		var script = document.createElement('script');
		// script.async = true;
		script.src = url;
		var entry = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(script, entry);
		script.onload = script.onreadystatechange = function() {
			var rdyState = script.readyState;
			if (!rdyState || /complete|loaded/.test(script.readyState)) {
				callback();
				script.onload = null;
				script.onreadystatechange = null;
			}
		};
	}

	function loadSupportingFiles(callback) {
		//console.log('loading supporting files !!! done loading all.');
		// calling
		callback();
	}
	
	function getWidgetParams() {
		//console.log('Reading paramters passed in from the publisher to the widget ... done.');
	}
	
	function getCookies(){
	  var pairs = document.cookie.split(";");
	  var cookies = {};
	  for (var i=0; i<pairs.length; i++){
		var pair = pairs[i].split("=");
		cookies[pair[0]] = unescape(pair[1]);
	  }
	  return cookies;
	}

	function getWidgetData(widgetUrl, callback) {
		var responseData;
		try{
			jQuery.ajax({
				url: widgetUrl,
				success: function (result) {
					if (result.isOk == false){
						
					}else{
						
						var reportData = result.reportDataRows;
						responseData = tranpose(reportData);
						//responseData = JSONToCSVConvertor(reportData);
					}
				},
				//not recommended to use synchronous - ikram will change
				async: false
			});
		}
		catch(e){
			
		}
		callback(responseData);
	}
	
	function tranpose(JSONData){
			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
		
			var map = new Map();
			for (var i = 0; i < arrData.length; i++) {
				var record = {};
				var name;
				var x;
				var y;
				for (var index in arrData[i]) {
					
					if(index === 'app_name'){
						name = arrData[i][index].displayValue;
					}
					
					else if(index === 'ct'){
						y = parseInt(arrData[i][index].displayValue);
					}
					
					else if(index === 'audit_date'){
						var d = new Date(arrData[i][index].displayValue);
						x = d.valueOf() + 18000000;
					}
				}
				
				record['x'] = x;
				record['y'] = y;
				map[name] = map[name] || [];
				map[name].push(record);	
			}
			
			
			var result = [];
			var arrData = typeof map != 'object' ? JSON.parse(map) : map;
			var keys = Object.keys(arrData);
			for(var i = 0; i < keys.length; i++){
				var row = {};
				row.type = "bar";
				row.key = keys[i];
				row.yAxis = "1";
				row.values = arrData[keys[i]];
				result.push(row);
			}
			return result;
	}
	
	function getMarkupContent(markupLocation, target){
		jQuery.ajax({
	        url: markupLocation,
		    success: function (result) {
	            if (result.isOk == false){
					
				}else{
	            	target.innerHTML = result;
				}
	        },
	        //not recommended to use synchronous - ikram will change
	        async: false
	    });
	}
	
	function renderWidget(widgetData, location) {
		
		var div = document.createElement('div');
		
		getMarkupContent(AreaWidget.commonUrl + "/markup/" + AreaWidget.widgetName, div);
		location.append(div);
		
		AreaWidget.widgetData = widgetData;
		
		app.controllerProvider.register(AreaWidget.controllerName, AreaWidget.controller);
	
		//printAllArtifacts('ecompApp');
		var mController = angular.element(document.getElementById("widgets"));
		mController.scope().activateThis(location, widgetData);
		
	}
	
	function printAllArtifacts(moduleName, controllerName) {
	    var queue = angular.module(moduleName)._invokeQueue;
	    for(var i=0;i<queue.length;i++) {
	        var call = queue[i];
	    }
	}
	
	function get(name){
	   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
	      return decodeURIComponent(name[1]);
	}

	loadSupportingFiles(function() {
			
		loadStylesheet(AreaWidget.commonUrl + '/' + AreaWidget.widgetName + '/style.css');		
		loadScript(AreaWidget.commonUrl + '/' + AreaWidget.widgetName + '/controller.js',
			function() {
				$('['+ AreaWidget.recipientDivDataAttrib + ']').each(function() {
					var location = jQuery(this);
					location.removeAttr(AreaWidget.recipientDivDataAttrib);
					var id = location.attr(AreaWidget.recipientDivDataAttrib);
					getWidgetData(AreaWidget.serviceURL, function(widgetData) {
						//console.log('Got widget data - ' + JSON.stringify(widgetData));
						isCssReady(function(){
							renderWidget(widgetData, location);
						});								
					});
				});
			}
		);
	});	
	return AreaWidget;	
})(window);
