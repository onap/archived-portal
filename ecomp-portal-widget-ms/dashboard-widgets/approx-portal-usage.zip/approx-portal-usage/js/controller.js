function LineCtrl2($scope) {
	
	var _this = this;	
	var max_num;
	function tranpose(JSONData){
		//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
		var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
		var max = 5;
		var map = new Map();
		for (var i = 0; i < arrData.length; i++) {
			var record = {};
			var name;
			for (var index in arrData[i]) {
				
				if(index === 'app'){
					name = arrData[i][index].displayValue;
				}
				
				else if(index === 'mins'){
					record['y'] = arrData[i][index].displayValue;
					max = Math.max(max, arrData[i][index].displayValue);
				}
				
				else if(index === 'audit_date'){
					var d = new Date(arrData[i][index].displayValue);
					record['x'] = d.valueOf();
				}
			}
			
			map[name] = map[name] || [];
			map[name].push(record);	
		}
		max_num = Math.ceil(max/100) * 100;
		var result = [];
		var arrData = typeof map != 'object' ? JSON.parse(map) : map;
		var keys = Object.keys(arrData);
		for(var i = 0; i < keys.length; i++){
			var row = {};
			row.type = "line";
			row.key = keys[i];
			row.yAxis = "1";
			row.values = arrData[keys[i]];
			result.push(row);
		}
		return result;
	}
	
	var historicalBarChart = tranpose(res.reportDataRows);
	//will be loaded and namespaced 'dynamically' ... later
	
	function redraw() { 
		d3.select('#lineChart2 svg') 
			.datum(historicalBarChart);
	} 
	$scope.initialize = function(){
		var chart;
		nv.addGraph(function() { 
			chart = nv.models.multiChart() 
				.dualaxis(false) 
				.legendPos('top')
				.margin({top: 30, right: 30, bottom: 50, left: 35}) 
				.showLegend(true) 
				.color(d3.scale.category10().range()); 
			chart.lines1.forceY([0, max_num]); 
			chart.lines2.forceY([0,1]); 
				chart.xAxis
				.axisLabel('') 
				.staggerLabels(false) 
				.showMaxMin(false) 
				.rotateLabels(-45) 
				.tickFormat(function(d) { 
				return d3.time.format('%m/%d/%Y')(new Date(d)) }); 
			chart.yAxis1
				.axisLabel('') 
				.tickFormat(d3.format(',d')); 
			d3.select('#lineChart2 svg') 
				.datum(historicalBarChart) 
				.transition().duration(1000) 
				.call(chart); 
			nv.utils.windowResize(chart.update); 
			return chart; 
		}); 
		setInterval(function () { 
			redraw(); 
		}, 1500) 
		
		if(historicalBarChart.length <= 0 ) {
			document.getElementById("lineChart2").innerHTML = "<div id='noData' class='nodatadiv'><b>No Data Available</b></div>";	
		}
		
	}
}