function CustomersCtrl($rootScope, applicationsService , $log,
			$window, userProfileService, $scope, $cookies, $timeout, $interval,
			$uibModal, dashboardService, ngDialog,$http, $controller) {
		
		var _this = this;			
		//activate spinner
		this.isLoading = true;
		$scope.getUserAppsIsDone = false;
		this.userProfileService = userProfileService;
		$scope.demoNum = 1; 
		$scope.widgetData = []; 
		$scope.ccdTabIndex = 1;
		$scope.openProjectTab = function(projectURL){
			
			projectURL = res.projectInfo.projectUrl + projectURL;
			console.log(projectURL);
			
			// Dynamic Project id E2E
			//var projectURL = '/ccd_e2e/project_open?project='+projectId
			
			// Dynamic Project id Dev environment 
			//var projectURL = 'https://www.e-access.att.com/ccd_dev/project_open?project='+projectId		
			//Mock Project id - E2E
			//var projectURL = '/ccd_e2e/project_open?project=d1effd23-de8e-4837-826b-f94b596d44b4';
			
			// Single tab
			var tabContent = { id: new Date(), title: "CCD 1707 DEV", url:projectURL};

			// open tab
			$cookies.putObject('addTab', tabContent );
		}
		
		/*Setting customer data*/
		$scope.toggleProjects = function(evt) {
			var elem = $(evt.target);
			$(elem).toggleClass('icon-chevron-down icon-chevron-up');
			$(elem).closest('li').find('ul').slideToggle();
		}
		
		$scope.showError = function showCustomerError(message){
			$scope.customersData = [];
			$scope.errorMessage = message;			
		}
		/*  DEV URL */
		//$scope.customerServiceUrl = "https://www.e-access.att.com/ccd_dev/CCD1/getcustomersforwidget?attuid=";
		
		$scope.customersData = [];
		_this.userProfileService.getUserProfile().then(function(loggedinUser){
			var usr = loggedinUser;
			if(usr && typeof usr.orgUserId !="undefined" && usr.orgUserId != "") {
				$scope.customersData = res.widgetInfo && res.widgetInfo.length > 0  ? _.groupBy(res.widgetInfo, 'customer_name') : [];
				$scope.projectInfo = res.projectInfo && res.projectInfo.projectUrl;
				_this.isLoading = false;
				
			} else {
				$scope.showError("User profile not available.");
				_this.isLoading = false;
			} 
		},function(){
				// no data connected, show error. 
				$scope.showError('Unable to get user information');
				_this.isLoading = false;
		});
		 

	}