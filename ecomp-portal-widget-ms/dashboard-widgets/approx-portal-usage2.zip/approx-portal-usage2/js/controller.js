function AreaCtrl($scope) {
	
	var _this = this;
	var chart; 
	var max_num;
	
	function tranpose(JSONData){
			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
		
			var map = new Map();
			var timeMap = new Map();
			for (var i = 0; i < arrData.length; i++) {
				var record = {};
				var name;
				var x;
				var y;
				for (var index in arrData[i]) {
					
					if(index === 'app_name'){
						name = arrData[i][index].displayValue;
					}
					
					else if(index === 'ct'){
						y = parseInt(arrData[i][index].displayValue);
					}
					
					else if(index === 'audit_date'){
						var d = new Date(arrData[i][index].displayValue);
						x = d.valueOf() + 18000000;
					}
				}
				timeMap[x] = timeMap[x] || [];
				timeMap[x].push(name);
				
				record['x'] = x;
				record['y'] = y;
				map[name] = map[name] || [];
				map[name].push(record);	
			}
			
			var result = [];
			var arrData = typeof map != 'object' ? JSON.parse(map) : map;
			var keys = Object.keys(arrData);
			
			for(var i = 0; i < keys.length; i++){
				var row = {};
				row.type = "bar";
				row.key = keys[i];
				row.yAxis = "1";
				//row.values = arrData[keys[i]];
				for(var n = 0; n < arrData[keys[i]].length; n++){
					if(timeMap[arrData[keys[i]][n].x].length != keys.length){
						arrData[keys[i]].splice(n, 1);
					}
				}
				row.values = arrData[keys[i]];
				//console.log(arrData[keys[i]]);
				result.push(row);
			}
			return result;
	}
	var historicalBarChart = tranpose(res.reportDataRows);

	function redraw() { 
		d3.select('#areaChart svg') 
			.datum(historicalBarChart);
	} 

	$scope.initialize = function(){
		nv.addGraph(function() { 
			chart = nv.models.multiBarChart() 
				.margin({top: 30, right: 30, bottom: 60, left: 35}) 
				.showLegend(true)  
			    .forceY([0, 12.0])
				.showControls(false) 
				.stacked(true)
				.logScale(false)
				.legendPos('top')
			    .color(d3.scale.category10().range()); 
			chart.xAxis
				.staggerLabels(false) 
				.showMaxMin(false) 
				.rotateLabels(-45) 
				.tickFormat(function(d) { 
				 return d3.time.format('%m/%d/%Y')(new Date(d)) }); 
			chart.yAxis
				.logScale(false)
				.axisLabel('') 
				.tickFormat(d3.format(',.0f')); 
			d3.select('#areaChart svg') 
				.datum(historicalBarChart) 
				.transition().duration(1000) 
				.call(chart); 
			nv.utils.windowResize(chart.update); 
			return chart; 
			
		}),redraw(),historicalBarChart.length<=0&&(document.getElementById("areaChart").innerHTML="<div id='noData' class='nodatadiv'><b>No Data Available</b></div>");; 
		

	}
}


						