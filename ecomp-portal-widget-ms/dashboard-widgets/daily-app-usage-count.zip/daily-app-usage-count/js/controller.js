function GaugeCtrl($scope) {
	
	 var _this = this;
	 var gauges = [];
	 var recordLength = 0;
	 var dataset;
	 var headerIds;
	 var headerNames;
	 
	 
	 function tranpose(JSONData){
			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
		
			var map = new Map();
			for (var i = 0; i < arrData.length; i++) {
				var record = {};
				var day;
				for (var index in arrData[i]) {
					
					if(index === 'app_name'){
						record['name'] = arrData[i][index].displayValue;
					}
					
					else if(index === 'ct'){
						record['ct'] = arrData[i][index].displayValue;
					}
					
					else if(index === 'audit_date'){
						day = arrData[i][index].displayValue;
					}
					
					else if(index === 'app_id'){
						record['id']  = arrData[i][index].displayValue;
					}
				}
				
				map[day] = map[day] || [];
				map[day].push(record);	
			}
			return map;
	}
	
	function JSONToCSVConvertor(JSONData) {

			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
			var keys = Object.keys(arrData);
			var CSV = '';
			var firstIndex = true;
			var appIds = [];
			var appNames = [];
			
			for(var i = keys.length-1; i >= 0; i--){
				var row = '"' + keys[i] + '"' + ',';
				var firstRow = '"YEARMONTH",';
				for(var n = 0; n < arrData[keys[i]].length; n++){
					var comma = n === arrData[keys[i]].length-1 ? '' : ',';
					if(firstIndex){
						firstRow += '"widget_' + arrData[keys[i]][n].id + '"' + comma;
						appIds.push('widget_' + arrData[keys[i]][n].id);
						appNames.push(arrData[keys[i]][n].name);
					}
					row += '"' + arrData[keys[i]][n].ct + '"'  + comma;
				}
				if(firstIndex){
					CSV += firstRow + '\n';
					headerIds = appIds;
					headerNames = appNames;
					firstIndex = false;
				}
				CSV += row + '\n';
			}
			return CSV;
	}
	var intermediateData = tranpose(res.reportDataRows);
	var appsData = JSONToCSVConvertor(intermediateData);
	
	var noData = false;
	if(appsData == ''){
		noData = true;
	}
	
	$scope.widgetData = [];
	 
	 function Gauge(t,i){
			this.placeholderName=t;
			var n=this;

			this.configure=function(t){
				this.config=t,
				this.config.size=1.6*this.config.size,
				this.config.raduis=1*this.config.size/2.4,
				this.config.cx=this.config.size/1.75,
				this.config.cy=this.config.size/2,
				this.config.min=void 0!=t.min?t.min:0,
				this.config.max=void 0!=t.max?t.max:100,
				this.config.range=this.config.max-this.config.min,
				this.config.majorTicks=t.majorTicks||5,
				this.config.minorTicks=t.minorTicks||2,
				this.config.greenColor=t.greenColor||"#109618",
				this.config.yellowColor=t.yellowColor||"#FF9900",
				this.config.redColor=t.redColor||"#DC3912",
				this.config.transitionDuration=t.transitionDuration||500
			},
			
			this.render=function(){
				this.body=d3.select("#"+this.placeholderName).append("svg:svg").attr("class","gauge").attr("width",this.config.size).attr("height",this.config.size),
				this.body.append("svg:circle").attr("cx",this.config.cx).attr("cy",this.config.cy).attr("r",this.config.raduis).style("fill","#ccc").style("stroke","#000").style("stroke-width","0.5px"),this.body.append("svg:circle").attr("cx",this.config.cx).attr("cy",this.config.cy).attr("r",.9*this.config.raduis).style("fill","#fff").style("stroke","#e0e0e0").style("stroke-width","2px");for(var t in this.config.greenZones)this.drawBand(this.config.greenZones[t].from,this.config.greenZones[t].to,n.config.greenColor);for(var t in this.config.yellowZones)this.drawBand(this.config.yellowZones[t].from,this.config.yellowZones[t].to,n.config.yellowColor);for(var t in this.config.redZones)this.drawBand(this.config.redZones[t].from,this.config.redZones[t].to,n.config.redColor);if(void 0!=this.config.label){var i=Math.round(this.config.size/12);this.body.append("svg:text").attr("x",this.config.cx).attr("y",this.config.cy/2+i/2).attr("dy",i/2).attr("text-anchor","middle").text(this.config.label).style("font-size",i+2+"px").style("fill","#333").style("stroke-width","0px")}for(var i=Math.round(this.config.size/16),e=this.config.range/(this.config.majorTicks-1),o=this.config.min;o<=this.config.max;o+=e){for(var a=e/this.config.minorTicks,r=o+a;r<Math.min(o+e,this.config.max);r+=a){var s=this.valueToPoint(r,.75),c=this.valueToPoint(r,.85);this.body.append("svg:line").attr("x1",s.x).attr("y1",s.y).attr("x2",c.x).attr("y2",c.y).style("stroke","#666").style("stroke-width","1px")}var s=this.valueToPoint(o,.7),c=this.valueToPoint(o,.85);if(this.body.append("svg:line").attr("x1",s.x).attr("y1",s.y).attr("x2",c.x).attr("y2",c.y).style("stroke","#333").style("stroke-width","2px"),o==this.config.min||o==this.config.max){var g=this.valueToPoint(o,.63);this.body.append("svg:text").attr("x",g.x).attr("y",g.y).attr("dy",i/3).attr("text-anchor",o==this.config.min?"start":"end").text(o).style("font-size",(i-4)+"px").style("fill","#333").style("stroke-width","0px")}}var f=this.body.append("svg:g").attr("class","pointerContainer"),h=(this.config.min+this.config.max)/2,l=this.buildPointerPath(h),d=d3.svg.line().x(function(t){return t.x}).y(function(t){return t.y}).interpolate("basis");f.selectAll("path").data([l]).enter().append("svg:path").attr("d",d).style("fill","#dc3912").style("stroke","#c63310").style("fill-opacity",.7),f.append("svg:circle").attr("cx",this.config.cx).attr("cy",this.config.cy).attr("r",.12*this.config.raduis).style("fill","#4684EE").style("stroke","#666").style("opacity",1);var i=Math.round(this.config.size/10);f.selectAll("text").data([h]).enter().append("svg:text").attr("x",this.config.cx).attr("y",this.config.size-this.config.cy/4-i).attr("dy",i/2).attr("text-anchor","middle").style("font-size",(i-4)+"px").style("fill","#000").style("stroke-width","0px"),this.redraw(this.config.min,0)
			},
			this.buildPointerPath=function(t){
				function i(t,i){var e=n.valueToPoint(t,i);return e.x-=n.config.cx,e.y-=n.config.cy,e}var e=this.config.range/13,o=i(t,.85),a=i(t-e,.12),r=i(t+e,.12),s=t-this.config.range*(1/.75)/2,c=i(s,.28),g=i(s-e,.12),f=i(s+e,.12);return[o,a,f,c,g,r,o]
			},
			this.drawBand=function(t,i,e){
				0>=i-t||this.body.append("svg:path").style("fill",e).attr("d",d3.svg.arc().startAngle(this.valueToRadians(t)).endAngle(this.valueToRadians(i)).innerRadius(.65*this.config.raduis).outerRadius(.85*this.config.raduis)).attr("transform",function(){return"translate("+n.config.cx+", "+n.config.cy+") rotate(270)"})
			},
			this.redraw=function(t,i,e){
				var o=this.body.select(".pointerContainer"),a=o.selectAll("text");y=a.attr("y"),dy=parseFloat(a.attr("dy")),a.selectAll("tspan").remove(),a.append("tspan").attr("x",90).attr("dy",0).text(Math.round(t)),a.append("tspan").attr("x",90).attr("dy",15).text(i),o.selectAll("text").style("fill",function(){var i=n.config.max-n.config.min;return Math.round(t)>.9*i?"#DC3912":Math.round(t)>.5*i&&Math.round(t)<.9*i?"#FF9900":"#000000"});var r=o.selectAll("path");r.transition().duration(void 0!=e?e:this.config.transitionDuration).attrTween("transform",function(){var i=t;t>n.config.max?i=n.config.max+.02*n.config.range:t<n.config.min&&(i=n.config.min-.02*n.config.range);var e=n.valueToDegrees(i)-90,o=n._currentRotation||e;return n._currentRotation=e,function(t){var i=o+(e-o)*t;return"translate("+n.config.cx+", "+n.config.cy+") rotate("+i+")"}})
			},
			this.valueToDegrees=function(t){
				return t/this.config.range*270-(this.config.min/this.config.range*270+45)
			},
			this.valueToRadians=function(t){
				return this.valueToDegrees(t)*Math.PI/180
			},
			this.valueToPoint=function(t,i){
				return{x:this.config.cx-this.config.raduis*i*Math.cos(this.valueToRadians(t)),y:this.config.cy-this.config.raduis*i*Math.sin(this.valueToRadians(t))}
			},
			this.configure(i)
			
	};
      
      function createGauge(name, label, min, max)
      {
        var config = 
        {
          size: 100,
          label: label,
          min: undefined != min ? min : 0,
          max: undefined != max ? max : 100,
          minorTicks: 5
        }
        
        var range = config.max - config.min;
        config.yellowZones = [{ from: config.min + range*0.50, to: config.min + range*0.9 }];
        config.redZones = [{ from: config.min + range*0.9, to: config.max }];
        
        gauges[name] = new Gauge(name, config);
        gauges[name].render();
      }
      
     
      function updateGauges(p) {
        for (var key in gauges) {
          var value = getValue(key, p);
          var date1 = getDate1(key, p);
          if(value)
          gauges[key].redraw(value, date1, 100);
        }
      }
	  
      function getValue(gauge_id, index) {
          var d = dataset[index];
          return eval('d.'+gauge_id);
      }
      
      function getDate1(gauge_id, index) {
          var d = dataset[index];
          return d.YEARMONTH;
      }      
      function getROUTER_CPU_Value(index) {
        d3.csv.parseRow("speedometer2.csv", function(data) {
          data.forEach(function(d, i) {
            if(i==index) {
              return d.ROUTER_CPU;
            }
          });
        });
      }

      function getAP_CPU_Value(index) {
        d3.csv("speedometer2.csv", function(data) {
          data.forEach(function(d, i) {
            if(i==index) {
              return d.AP_CPU;
            }
          });
        });
      }
      function updateData() {
        for (var i=0; i<recordLength; i++) {

        }
      }	
	
	  $scope.appIds = [];
      function createGauges(){
		  var appNames = headerNames;
		  for(var i = 0; i < $scope.appIds.length; i++){
			  createGauge($scope.appIds[i], appNames[i], 0, 50);
		  }  
	  }

     $scope.initialize = function()
      {
        $scope.appIds = headerIds;
		
		if(noData == true){
			document.getElementById("widget-gauge-details").innerHTML = "<div id='noData' class='nodatadiv'><b>No Data Available</b></div>";
			return;
		}
		
		var sourceHTML = "";
		for(var i = 0; i < $scope.appIds.length; i++){
			sourceHTML += "<div class='widget-gauge-circle' id='" + $scope.appIds[i] + "'></div>";
		}
		document.getElementById("widget-gauge-details").innerHTML = sourceHTML;
		
		
		createGauges();
		
        dataset = d3.csv.parse(appsData);
       	  recordLength = dataset.length;
          dataset.some(function(d, i) {
             updateGauges(i);
          });
       
        var interval = 1000; // one second
        var count = 2;

        var makeCallback = function() {
			return function() {
				updateGauges(count++);
				if(count < recordLength) {
				  d3.timer(makeCallback(),interval);
				  return true;
				} else {
				  count = 0;
				  d3.timer(makeCallback(),interval);
				  return true;
				}
			}
		};
		d3.timer(makeCallback(),interval);
     }
}


						